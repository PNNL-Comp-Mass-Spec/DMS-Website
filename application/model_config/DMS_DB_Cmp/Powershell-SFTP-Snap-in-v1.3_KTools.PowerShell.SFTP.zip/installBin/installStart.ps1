﻿function checkX64{if($(Get-WmiObject Win32_OperatingSystem  | select OSArchitecture).OSArchitecture -eq "64-Bit"){return 1;}else{return 0;}}
$snapinWrapperDll = "`"$env:ProgramFiles\KTools\KTools.PowerShell.SFTP\bin\KTools.PowerShell.SFTP.dll`"";

function prepareSources
{
    Write-Host "Preparing Snap-In sources..."
    if(![system.io.directory]::Exists("$env:ProgramFiles\KTools\KTools.PowerShell.SFTP\bin"))
    {
        $newDir = [system.io.directory]::CreateDirectory("$env:ProgramFiles\KTools\KTools.PowerShell.SFTP\bin");
    }

    foreach($file in [system.io.directory]::GetFiles("bin"))
    {
        $fileName = $file.Replace("bin\", "");
        $copyFile = [system.io.file]::Copy($file, "$env:ProgramFiles\KTools\KTools.PowerShell.SFTP\bin\$fileName", $true);
    }
}

function installPSSnapIn-PS2x86
{
    Write-Host "Installing Snap-In for PowerShell 2 x86";
    $frameWorkInstallerPath = "$env:windir\Microsoft.NET\Framework\v2.0.50727\InstallUtil.exe";
    $process = Start-Process -FilePath $frameWorkInstallerPath -ArgumentList $snapinWrapperDll -Wait;
}
function installPSSnapIn-PS2x64
{
    Write-Host "Installing Snap-In for PowerShell 2 x64";
    $frameWorkInstallerPath = "$env:windir\Microsoft.NET\Framework64\v2.0.50727\InstallUtil.exe"
    $process = Start-Process -FilePath $frameWorkInstallerPath -ArgumentList $snapinWrapperDll -Wait;
}
function installPSSnapIn-PS3x86
{
    Write-Host "Installing Snap-In for PowerShell 3 x86";
    $frameWorkInstallerPath = "$env:windir\Microsoft.NET\Framework\v4.0.30319\InstallUtil.exe"
    $process = Start-Process -FilePath $frameWorkInstallerPath -ArgumentList $snapinWrapperDll -Wait;
}
function installPSSnapIn-PS3x64
{
    Write-Host "Installing Snap-In for PowerShell 3 x64";
    $frameWorkInstallerPath = "$env:windir\Microsoft.NET\Framework64\v4.0.30319\InstallUtil.exe"
    $process = Start-Process -FilePath $frameWorkInstallerPath -ArgumentList $snapinWrapperDll -Wait;
}

# Get the ID and security principal of the current user account
 $myWindowsID=[System.Security.Principal.WindowsIdentity]::GetCurrent()
 $myWindowsPrincipal=new-object System.Security.Principal.WindowsPrincipal($myWindowsID)
  
 # Get the security principal for the Administrator role
 $adminRole=[System.Security.Principal.WindowsBuiltInRole]::Administrator
  
 # Check to see if we are currently running "as Administrator"
 if ($myWindowsPrincipal.IsInRole($adminRole))
    {
    # We are running "as Administrator" - so change the title and background color to indicate this
    $Host.UI.RawUI.WindowTitle = $myInvocation.MyCommand.Definition + "(Elevated)"
    $Host.UI.RawUI.BackgroundColor = "DarkBlue"
    clear-host
    }
 else
    {    
    # Exit from the current, unelevated, process
    Write-Host "Administrative privileges not found! Press any key to exit..." -NoNewline;
    Read-Host;
    exit
    }
  
Write-Host "Installer is now installing K-Tools Powershell SFTP Snap-In"

$psHostVersion = $(Get-Host).Version.Major;
$hostOSx64 = checkX64;

if($psHostVersion -eq 3)
{
    prepareSources;

    if($hostOSx64 -eq 1)
    {
        installPSSnapIn-PS3x64;
        installPSSnapIn-PS3x86;
        installPSSnapIn-PS2x64;
        installPSSnapIn-PS2x86;
    }
    else
    {
        installPSSnapIn-PS3x86;
        installPSSnapIn-PS2x86;
    }
}
else
{
    prepareSources;

    if($hostOSx64 -eq 1)
    {
        installPSSnapIn-PS2x64;
        installPSSnapIn-PS2x86;
    }
    else
    {
        installPSSnapIn-PS2x86;
    }
}
Write-Host "Installation Script Completed. Press any key to exit..." -NoNewline
Read-Host;