﻿#Add the SFTP snap-in
Add-PSSnapin KTools.PowerShell.SFTP

#Define some variables
$sftpHost = "upload.macawhosting.net"
$userName = "admin_kraap"
$userPassword = "NDI1234!"

#Open the SFTP connection
$sftp = Open-SFTPServer -serverAddress $sftpHost -userName $userName -userPassword $userPassword

#Check if the connection is established
if($sftp.Connected)
{
    Write-Host "We have an active SFTP connection"
}

#Close the SFTP connection
$sftp.Close()