﻿Add-PSSnapin KTools.PowerShell.SFTP
function getSFTPFullPathFiles($sftpHost, $userName, $userPassword)
{
    $sftp = Open-SFTPServer -serverAddress $sftpHost -userName $userName -userPassword $userPassword
    $dirs = $sftp.GetDirList("/")
    $sftpFileslist = New-Object 'System.Collections.Generic.List[string]'

    foreach($dir in $dirs)
    {
        if(!$($dir -eq "."))
        {
            if(!$($dir -eq ".."))
            {
                $files = $sftp.GetFileList("/$dir/")
                foreach($file in $files)
                {
                    $sftpFileslist.Add("/$dir/$file")
                }
            }
        }
    }

    $sftp.Close()
    return $sftpFileslist
}

function getSFTPFile($sftpHost, $userName, $userPassword, $remoteFilePath)
{
    $sftp = Open-SFTPServer -serverAddress $sftpHost -userName $userName -userPassword $userPassword
    $sftp.Get($remoteFilePath, $($(get-location).Path))
    $sftp.Close()
    $downloadedFile = $remoteFilePath
    $downloadedFile = $($downloadedFile.Substring($downloadedFile.LastIndexOf('/'), $($downloadedFile.Length - $downloadedFile.LastIndexOf('/')))).Replace("/", "")
    $downloadedFile = "$($(get-location).Path)\$downloadedFile"
    return $downloadedFile
}

Write-Host ""
Write-Host "Please enter the host name : " -NoNewline
$sftpHost = Read-Host

if($sftpHost -eq "")
{
    Write-Host "Hostname cannot be empty !"
    return
}

Write-Host "Please enter your username : " -NoNewline
$userName = Read-Host

if($userName -eq "")
{
    Write-Host "Username cannot be empty !"
    return
}

Write-Host "Please enter your password : " -NoNewline
$secureUserPassword = Read-Host -AsSecureString
$Credentials = New-Object 'System.Management.Automation.PSCredential' -ArgumentList $userName, $secureUserPassword
$userPassword = $Credentials.GetNetworkCredential().Password


if($userPassword -eq "")
{
    Write-Host "Password cannot be empty !"
    return
}

$files = getSFTPFullPathFiles $sftpHost $userName $userPassword

Write-Host ""
Write-Host "We have found $($files.Count) files in the root directory and 1st level sub directory`s"
Write-Host "Would you like to list these files ? (y/n):" -NoNewline
$retval = Read-Host
Write-Host ""
if($retval.ToLower() -eq "y")
{
    $files
    Write-Host ""
    Write-Host "Would you like to download the first file in the list ?(y/n):" -NoNewline
    $retval = Read-Host

    if($retval.ToLower() -eq "y")
    {
        try
        {
            $localFile = getSFTPFile $sftpHost $userName $userPassword $files[0]
            Write-Host "Your file should be download to $localFile :-)" -ForegroundColor Green
        }
        catch
        {
            Write-Host "Something went horribly wrong while downloading your file :-(" -ForegroundColor Red
        }
        
        Write-Host ""
    }
}