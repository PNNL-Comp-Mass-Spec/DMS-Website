﻿#Add the SFTP snap-in
Add-PSSnapin KTools.PowerShell.SFTP

#Define some variables
$sftpHost = "sftp.server.com"
$userName = "yourUserName"
$userPassword = "yourPassword"

#Open the SFTP connection
$sftp = Open-SFTPServer -serverAddress $sftpHost -userName $userName -userPassword $userPassword

#Show directory`s from remote root folder
$sftp.GetDirList("/")

#Show file`s from remote root folder
$sftp.GetFileList("/")

#Close the SFTP connection
$sftp.Close()