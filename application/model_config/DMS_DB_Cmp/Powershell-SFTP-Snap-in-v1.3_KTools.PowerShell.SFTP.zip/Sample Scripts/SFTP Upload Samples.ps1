﻿#Add the SFTP snap-in
Add-PSSnapin KTools.PowerShell.SFTP

#Define some variables
$sftpHost = "sftp.server.com"
$userName = "yourUserName"
$userPassword = "yourPassword"
$localFile = "C:\The\File\You\Have.txt"
$localFileList = "C:\file1.txt", "C:\file2.txt", "C:\file3.txt"

#Open the SFTP connection
$sftp = Open-SFTPServer -serverAddress $sftpHost -userName $userName -userPassword $userPassword

#Upload the local file to the root folder on the SFTP server
$sftp.Put($localFile)

#Upload the local file to another folder on the SFTP server
$sftp.Put($localFile, "/SomeFolder")

#Upload the local file to the root folder on the SFTP server with a specific filename
$sftp.Put($localFile, "/downloadedFile.txt")

#Upload a list of local files to the root folder on the SFTP server
$sftp.Put($localFileList)

#Upload a list of local files to another folder on the SFTP server
$sftp.Put($localFileList, "/SomeFolder")

#Close the SFTP connection
$sftp.Close()