﻿#Add the SFTP snap-in
Add-PSSnapin KTools.PowerShell.SFTP

#Define some variables
$sftpHost = "sftp.server.com"
$userName = "yourUserName"
$userPassword = "yourPassword"
$remoteFile = "/The/File/You/WantToDelete.txt"

#Open the SFTP connection
$sftp = Open-SFTPServer -serverAddress $sftpHost -userName $userName -userPassword $userPassword

#Check if the connection is established
$sftp.Delete($remoteFile)

#Close the SFTP connection
$sftp.Close()