﻿#Add the SFTP snap-in
Add-PSSnapin KTools.PowerShell.SFTP

#Define some variables
$sftpHost = "sftp.server.com"
$userName = "yourUserName"
$userPassword = "yourPassword"
$remoteFile = "/The/File/You/Want.txt"
$remoteFileList = "/file1.txt", "/file2.txt", "/file3.txt"

#Open the SFTP connection
$sftp = Open-SFTPServer -serverAddress $sftpHost -userName $userName -userPassword $userPassword

#Download the remote file to the current folder
$sftp.Get($remoteFile)

#Download the remote file to the C: drive`s root
$sftp.Get($remoteFile, "C:\")

#Download the remote file to the specified filename
$sftp.Get($remoteFile, "C:\downloadedFile.txt")

#Download a list of remote files to the current folder
$sftp.Get($remoteFileList)

#Download the remote file to the C: drive`s root
$sftp.Get($remoteFileList, "C:\")

#Close the SFTP connection
$sftp.Close()